package com.example.hitungvolumebalok;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    EditText EtPanjang, EtLebar, EtTinggi;
    Button BtnHitung;
    TextView TvResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        EtPanjang = findViewById(R.id.Panjang);
        EtLebar = findViewById(R.id.Lebar);
        EtTinggi = findViewById(R.id.Tinggi);
        BtnHitung = findViewById(R.id.Hitung);
        TvResult = findViewById(R.id.Result);
        BtnHitung.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.Hitung) {
            String inputPanjang = EtPanjang.getText().toString().trim();
            String inputLebar = EtLebar.getText().toString().trim();
            String inputTinggi = EtTinggi.getText().toString().trim();

            boolean number = false;
            boolean EmptyNumber = false;

            if (TextUtils.isEmpty(inputPanjang)) {
                EmptyNumber = true;
                EtPanjang.setError("Kolom Panjang Tidak Boleh Kosong");
            }

            if (TextUtils.isEmpty(inputLebar)) {
                EmptyNumber = true;
                EtLebar.setError("Kolom Lebar Tidak Boleh Kosong");
            }

            if (TextUtils.isEmpty(inputTinggi)) {
                EmptyNumber = true;
                EtTinggi.setError("Kolom Tinggi Tidak Boleh Kosong");
            }
            Double nilaipanjang = toDouble(inputPanjang);
            Double nilailebar = toDouble(inputLebar);
            Double nilaitinggi = toDouble(inputTinggi);

            if(nilaipanjang==null){
                number=true;
                EtPanjang.setError("Invalid Number in panjang kolom");
            }
            if(nilailebar==null){
                number=true;
                EtLebar.setError("Invalid Number in Lebar kolom");
            }
            if(nilaitinggi==null){
                number=true;
                EtTinggi.setError("Invalid Number in Tinggi kolom");
            }

            if(!number && !EmptyNumber)
            {
                double Volume =nilaipanjang*nilailebar*nilaitinggi;
                TvResult.setText(String.valueOf(Volume));
            }



        }
    }
    Double toDouble(String str) {
        try {
            return Double.valueOf(str);
        } catch (NumberFormatException e) {
            return null;
        }
    }
}

